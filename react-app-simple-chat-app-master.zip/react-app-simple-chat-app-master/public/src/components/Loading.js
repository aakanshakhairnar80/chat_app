// Loading component
export default (props) => {
	return (
		<div className="loading-div">
			<img src="images/loading.gif" className="loading-gif" />
		</div>
	)
}
