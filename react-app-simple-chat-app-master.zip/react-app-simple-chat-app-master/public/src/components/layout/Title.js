// Title component
export default () => {
  return (
    <div className="title">
      Simple <span className="bold-title">Chat</span>
    </div>
  )
}
