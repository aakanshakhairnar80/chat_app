﻿namespace GameZone.Services
{
    public class GamesService : IGamesService
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly string _imagesPath;

        public GamesService(ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
            _imagesPath = $"{_webHostEnvironment.WebRootPath}{FileSettings.ImagesPath}";
        }

        public IEnumerable<Game>? GetAll()
        {
            return _context.Games
                .Include(g => g.Category)
                .Include(g => g.GameDevices)
                .ThenInclude(gd => gd.Device)
                .AsNoTracking()
                .ToList();
        }

        public Game? GetById(int id)
        {
            if(id > 0)
            {
                return _context.Games
                .Include(g => g.Category)
                .Include(g => g.GameDevices)
                .ThenInclude(gd => gd.Device)
                .AsNoTracking()
                .SingleOrDefault(g => g.Id == id);
            }

            return new Game();
        }

        public async Task<bool> Create(CreateGameFormVM gameModel)
        {
            if (gameModel != null)
            {
                var coverName = await SaveCover(gameModel.Cover);

                Game newGame = new()
                {
                    Name = gameModel.Name,
                    Description = gameModel.Description,
                    CategoryId = gameModel.CategoryId,
                    Cover = coverName,
                    GameDevices = gameModel?.SelectedDevices?
                        .Select(d => new GameDevice { DeviceId = d })?.ToList()
                        ?? new List<GameDevice>(),
                };

                _context.Add(newGame);
                _context.SaveChanges();

                return true;
            }

            return false;
        }

        public async Task<bool> Update(EditGameFormVM editedGameModel)
        {
            if (editedGameModel is null)
                return false;

            Game? game = _context.Games
                .Include(g => g.GameDevices)
                .SingleOrDefault(g => g.Id == editedGameModel.Id);

            if (game is null)
                return false;

            bool hasNewCover = editedGameModel.Cover is not null;
            string oldCover = game.Cover!;

            game.Name = editedGameModel.Name;
            game.Description = editedGameModel.Description;
            game.CategoryId = editedGameModel.CategoryId;
            game.GameDevices = editedGameModel.SelectedDevices.Select(d => new GameDevice() { DeviceId = d }).ToList();

            if (hasNewCover)
                game.Cover = await SaveCover(editedGameModel.Cover!);

            var effectedRows = _context.SaveChanges();

            if (effectedRows > 0)
            {
                if (hasNewCover)
                    File.Delete(Path.Combine(_imagesPath, oldCover));

                return true;
            }
            else
            {
                if (hasNewCover)
                    File.Delete(Path.Combine(_imagesPath, game.Cover!));
                game.Cover = oldCover;
                return false;
            }
        }

        public bool Delete(int id)
        {
            Game? game = _context.Games.Include(g => g.GameDevices).SingleOrDefault(g => g.Id == id);
            if(game is null)
                return false;

            _context.Remove(game);
            var effectedRows = _context.SaveChanges();

            if(effectedRows > 0)
            {
                File.Delete(Path.Combine(_imagesPath, game.Cover!));
                return true;
            }

            return false;
        }

        private async Task<string> SaveCover(IFormFile cover)
        {
            var coverName = $"{Guid.NewGuid()}{Path.GetExtension(cover.FileName)}";
            var path = Path.Combine(_imagesPath, coverName);

            using var stream = File.Create(path);
            await cover.CopyToAsync(stream);

            return coverName;
        }
    }
}