﻿namespace GameZone.Services
{
    public interface IGamesService
    {
        IEnumerable<Game>? GetAll();
        Game? GetById(int id);
        Task<bool> Create(CreateGameFormVM gameModel);
        Task<bool> Update(EditGameFormVM editedGameModel);
        bool Delete(int id);
    }
}
