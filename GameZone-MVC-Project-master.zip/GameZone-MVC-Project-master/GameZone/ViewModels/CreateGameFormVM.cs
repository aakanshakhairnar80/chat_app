﻿using GameZone.Attributes;

namespace GameZone.ViewModels
{
    public class CreateGameFormVM : GameFormVM
    {
        [AllowedExtensions(FileSettings.AllowedExtensions), 
            MaxFileSize(FileSettings.MaxFileSizeInBytes)]
        public IFormFile Cover { get; set; } = default!;
    }
}
