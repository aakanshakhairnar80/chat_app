﻿

using System.IO;

namespace GameZone.Controllers
{
    public class GamesController : Controller
    {
        private readonly ICategoriesService _categoriesService;
        private readonly IDevicesService _devicesService;
        private readonly IGamesService _gamesService;

        public GamesController(ICategoriesService categoriesService, 
            IDevicesService devicesService,
            IGamesService gamesService)
        {
            _categoriesService = categoriesService;
            _devicesService = devicesService;
            _gamesService = gamesService;
        }

        public IActionResult Index()
        {
            var games = _gamesService?.GetAll() ?? new List<Game>();
            return View(games);
        }

        public IActionResult Details(int gameId)
        {
            var seletedGame = _gamesService.GetById(gameId);

            if (seletedGame == null)
                return NotFound();

            return View(seletedGame);
        }

        public IActionResult Create()
        {
            CreateGameFormVM viewModel = new()
            {
                Categories = _categoriesService.GetCategoriesList(),
                Devices = _devicesService.GetDevicesList(),
            };
            
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken] // validate the hidden input in the form that
        //ensures that the token is correct and can handle this request
        public async Task<IActionResult> Create(CreateGameFormVM modelData)
        {
            if (!ModelState.IsValid)
            {
                modelData.Categories = _categoriesService.GetCategoriesList();
                modelData.Devices = _devicesService.GetDevicesList();

                return View(modelData);
            }

            if (ModelState.IsValid && modelData != null)
                await _gamesService.Create(modelData);

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            Game? selectedGame = _gamesService.GetById(id);
            if (selectedGame == null)
                return NotFound();

            EditGameFormVM model = new()
            {
                Id = id,
                Name = selectedGame.Name,
                CategoryId = selectedGame.CategoryId,
                Categories = _categoriesService.GetCategoriesList(),
                SelectedDevices = selectedGame.GameDevices.Select(gd => gd.DeviceId).ToList(),
                Devices = _devicesService.GetDevicesList(),
                Description = selectedGame.Description ?? string.Empty,
                CurrentCover = selectedGame.Cover,
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EditGameFormVM editedGame)
        {
            if (!ModelState.IsValid)
            {
                //editedGame.Categories = _categoriesService.GetCategoriesList();
                //editedGame.Devices = _devicesService.GetDevicesList();
                //return View(editedGame);

                return View(editedGame.Id);
            }

            if(ModelState.IsValid && editedGame != null)
            {
                bool isUpdated = await _gamesService.Update(editedGame);
                if (!isUpdated)
                    return BadRequest();
            }

            return RedirectToAction(nameof(Index));
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            bool isDeleted = _gamesService.Delete(id);
            
            return isDeleted ? Ok() : BadRequest();
        }
    }
}
