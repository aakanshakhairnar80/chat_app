﻿using GameZone.Models;
using System.Runtime.Serialization;

namespace GameZone.Data
{
    public class ApplicationDbContext : DbContext
    {
        public virtual DbSet<Game> Games { get; set; }
        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<Device> Devices { get; set; }
        public virtual DbSet<GameDevice> GameDevices { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Game>()
                        .HasOne(g => g.Category)
                        .WithMany(c => c.Games)
                        .HasForeignKey(g => g.CategoryId);

            modelBuilder.Entity<Device>()
                        .HasMany(d => d.GameDevices)
                        .WithOne(gd => gd.Device)
                        .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<Game>()
                        .HasMany(g => g.GameDevices)
                        .WithOne(gd => gd.Game);

            modelBuilder.Entity<GameDevice>()
                        .HasKey(gd => new { gd.DeviceId, gd.GameId });

            #region Data Seeding
            modelBuilder.Entity<Category>()
                        .HasData(
                        [
                            new Category { Id = 1, Name = "Sports" },
                            new Category { Id = 2, Name = "Action" },
                            new Category { Id = 3, Name = "Adventure" },
                            new Category { Id = 4, Name = "Racing" },
                            new Category { Id = 5, Name = "Fighting" },
                            new Category { Id = 6, Name = "Film" },
                        ]);

            modelBuilder.Entity<Device>()
                        .HasData(
                        [
                            new Device { Id = 1, Name = "PlayStation", Icon = "bi bi-playstation" },
                            new Device { Id = 2, Name = "XBox", Icon = "bi bi-xbox" },
                            new Device { Id = 3, Name = "Nintendo Switch", Icon = "bi bi-nintendo-switch" },
                            new Device { Id = 4, Name = "PC", Icon = "bi bi-pc-display" },
                        ]);
            #endregion

            base.OnModelCreating(modelBuilder);
        }
    }
}
