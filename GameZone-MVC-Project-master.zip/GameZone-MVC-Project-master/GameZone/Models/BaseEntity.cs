﻿namespace GameZone.Models
{
    public class BaseEntity
    {
        public int Id { get; set; }

        [StringLength(250)]
        public string Name { get; set; } = string.Empty;
    }
}
