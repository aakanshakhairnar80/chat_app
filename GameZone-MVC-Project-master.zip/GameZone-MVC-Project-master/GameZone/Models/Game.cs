﻿namespace GameZone.Models
{
    public class Game : BaseEntity
    {
        [StringLength(2500)]
        public string? Description { get; set; }

        [StringLength(500)]
        public string? Cover { get; set; }

        public int CategoryId { get; set; }

        public virtual Category? Category { get; set; }
        public virtual ICollection<GameDevice> GameDevices { get; set; } = new HashSet<GameDevice>();
    }
}
